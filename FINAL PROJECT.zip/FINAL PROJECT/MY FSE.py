from pygame import *
from random import randint

#guy variables
X=0
Y=1
VY=2
jumping=3
score=4
progress = 5
page = 6
angle = 7
previouspg = 8
shotX = 9
finalscore = 10
power = 11

init()

screen = display.set_mode((800,600))
#importing
display.set_caption("Geometry Dash")
backPic = image.load("GeoBackground2.png")
backPic2 = image.load("GeoBackgroundlevel3.png")
platformMask3 = image.load("masklevel3.png")
platformMask2 = image.load("mask.png")
wallMask = image.load("mask2.png")
menubackgroundtransform = image.load("menubackground.png")
geotitletransform = image.load("geotitle.png")
laserPictransform = image.load("laser.png")
lvlcom = image.load("lvlcom.png")
spikePictransform = image.load("spike.png")
coinPictransform = image.load("coin.png")
greenpoweruptransform = image.load("greenpowerup.png")
redpoweruptransform = image.load("redpowerup.png")
yellowringtransform = image.load("YellowRing.png")
magentaringtransform = image.load("MagentaRing.png")
breakblockPictransform = image.load("BrickBlock.png")
playtransform = image.load("play.png")
level1texttransform = image.load("level1text.png")
character = image.load("character.png")
character2 = image.load("character2.png")
character3 = image.load("character3.png")
#transforming
menubackground = transform.scale(menubackgroundtransform,(800,600))
geotitle = transform.scale(geotitletransform,(300,50))
laserPic = transform.scale(laserPictransform,(30,20))
spikePic = transform.scale(spikePictransform,(20,30))
coinPic = transform.scale(coinPictransform,(20,20))
greenpowerup = transform.scale(greenpoweruptransform,(20,20))
redpowerup = transform.scale(redpoweruptransform,(20,20))
yellowring = transform.scale(yellowringtransform,(30,30))
magentaring = transform.scale(magentaringtransform,(30,30))
breakblockPic = transform.scale(breakblockPictransform,(20,250))
play = transform.smoothscale(playtransform,(150,50))
level1text = transform.smoothscale(level1texttransform,(150,50))
guyPic = transform.scale(character,(31,31))
guyPic2 = transform.scale(character2,(31,31))
guyPic3 = transform.scale(character3,(31,31))
#sounds
mixer.music.load("song3.mp3")
mixer.music.load("explode_11.mp3")
#textfiles
jblockpos = open("jumpblocks.txt").read().strip().replace(",","\n").split()
bblockpos = open("breakblocks.txt").read().strip().replace(",","\n").split()
spikepos = open("spikes.txt").read().strip().replace(",","\n").split()
spikepos3 = open("spikes3.txt").read().strip().replace(",","\n").split()
coinpos = open("coins.txt").read().strip().replace(",","\n").split()

darkblue = (0,0,0)
shots = []
#Character Pics
character1 = False
character2 = True
character3 = False

def menu(guy,screen,page):
    if guy[page] == "menu":
        screen.blit(menubackground,(0,0))
        screen.blit(geotitle,(225,50))
        buttons = [draw.rect(screen,darkblue,(300,150,150,50)),draw.rect(screen,darkblue,(300,250,150,50)),draw.rect(screen,darkblue,(300,350,150,50)),draw.rect(screen,darkblue,(300,450,150,50))]
        screen.blit(play,(300,150))
        if buttons[0].collidepoint(mx,my):
            draw.rect(screen,(0,0,0),(300,150,150,50),1)
        if mb[0]==1 and buttons[0].collidepoint(mx,my):
            guy[page] = "select"
        if mb[0]==1 and buttons[1].collidepoint(mx,my):
            guy[page] = "store"
            print("store")
    if guy[page] == "select":
        screen.blit(menubackground,(0,0))
        screen.blit(geotitle,(225,50))
        levels = [draw.rect(screen,(0,0,0),(100,200,150,150)),draw.rect(screen,(255,0,0),(300,200,150,150)),draw.rect(screen,(255,0,0),(500,200,150,150))]
        screen.blit(level1text,(100,250))
        if mb[0]==1 and levels[0].collidepoint(mx,my):
            guy[page]="lvl1"
        if mb[0]==1 and levels[1].collidepoint(mx,my):
            guy[page]="lvl2"
        if mb[0]==1 and levels[2].collidepoint(mx,my):
            guy[page]="lvl3"

def drawScene2(screen,guy,drawing): #scene for level 2
    offset = 250-guy[X]
    screen.blit(backPic, (offset,0)) #moving the background

    draw.line(screen,(0,0,0),(0,509),(10000,509),1) #ground line

    #progress bar
    draw.rect(screen,(0,0,0),(325,20,135,15),1)
    draw.rect(screen,(0,255,0),(327,20,guy[progress],13))

    #hitbox for collecting coins
    hitbox = Rect(guy[X]+20,guy[Y],1,31)
    h = hitbox.move(offset,0)

    for spike in spikes: #drawing spikes
        s = spike.move(offset,0)
        screen.blit(spikePic,s)

    for coin in range(len(coins)): #drawing coins
        c = coins[coin].move(offset,0)
        if drawing[coin] == True:
            screen.blit(coinPic,c)
        if h.colliderect(c):
            guy[score] += 1
            drawing[coin] = False

    #drawing rotated pic
    if character3 == True:
        rotatePic = transform.rotate(guyPic3,guy[angle])
    if character2 == True:
        rotatePic = transform.rotate(guyPic2,guy[angle])
    if character1 == True:
        rotatePic = transform.rotate(guyPic,guy[angle])
    screen.blit(rotatePic, (250,guy[Y]))

def drawScene3(screen,guy,drawing): #scene for level 3
    offset = 250-guy[X]
    screen.blit(backPic2, (offset,0)) #moving the background
    
    draw.line(screen,(0,0,0),(0,509),(10000,509),1) 

    hitbox = Rect(guy[X]+1,guy[Y],35,35)
    h = hitbox.move(offset,0)

    for spike in spikes3:
        s = spike.move(offset,0)
        screen.blit(spikePic,s)

    for jbs in jumpblocks:
        j = jbs.move(offset,0)
        if h.colliderect(j):
            guy[jumping] = False
            screen.blit(magentaring,j)
        else:
            screen.blit(yellowring,j)
            
    p = powerup.move(offset,0)
    screen.blit(redpowerup,p)
    if guy[power] == True:
        screen.blit(greenpowerup,p)
        
    for bblock in range(len(breakblocks)):
        b = breakblocks[bblock].move(offset,0)
        if drawing2[bblock] == True:
            screen.blit(breakblockPic,b)
            if h.colliderect(b):
                for i in range(len(drawing2)):
                    drawing2[i] = True
                guy[Y] = 478
                guy[X] = 250
                guy[shotX] = 250
                guy[score] = 0
                guy[progress] = 0
                guy[power] = False
                mixer.music.play(1)
                time.wait(300)

    #----------------------------------------------------
    #shooting
    keys = key.get_pressed()
    global shots
    global shotY
    if guy[power] == True:
        if keys[K_UP]:
            shots = ['shot']
            if guy[shotX] == 250:
                shotY = guy[Y]

        if len(shots)==1:
            guy[shotX]+=10

            shothitbox = Rect(guy[shotX],shotY,20,10)
            screen.blit(laserPic,(guy[shotX],shotY))
            
            for bblock in range(len(breakblocks)):
                b = breakblocks[bblock].move(offset,0)
                if shothitbox.colliderect(b):
                    drawing2[bblock] = False
        
        if guy[shotX] > 700:
            guy[shotX] = 250
            shots.remove('shot')
    #-----------------------------------------------------   
    
    if character3 == True:
        rotatePic = transform.rotate(guyPic3,guy[angle])
    if character2 == True:
        rotatePic = transform.rotate(guyPic2,guy[angle])
    if character1 == True:
        rotatePic = transform.rotate(guyPic,guy[angle])
    screen.blit(rotatePic, (250,guy[Y]))

def move(guy):
    if guy[page] == "lvl2":
        if guy[X] < 15401:
            guy[X] += 6
    if guy[page] == "lvl3":
        if guy[X] < 15401:
            guy[X] += 5
            
def jump(guy):
    if guy[page] == "lvl2":
        keys = key.get_pressed()
        
        if keys[K_SPACE] and guy[jumping]==False:
            guy[VY] = -13
            guy[jumping]=True

        guy[Y]+=guy[VY]
        #if guy is on ground stop jumping
        if guy[Y] >= 478:
            guy[Y] = 478
            guy[VY] = 0
            guy[jumping]=False
        guy[VY]+= 1
            
    if guy[page] == "lvl3":
        keys = key.get_pressed()
        
        if keys[K_SPACE] and guy[jumping]==False:
            guy[VY] = -13
            guy[jumping]=True

        guy[Y]+=guy[VY]
        #if guy is on ground stop jumping
        if guy[Y] >= 478:
            guy[Y] = 478
            guy[VY] = 0
            guy[jumping]=False
        guy[VY]+= 1

def upsidedownjump(guy):
    keys = key.get_pressed()
    hitbox = Rect(guy[X],guy[Y],29,31)
    
    if keys[K_SPACE] and guy[jumping]==False:
        guy[VY] += 13
        guy[jumping]=True

    guy[Y]+=guy[VY]
    if guy[Y] <= 0:
        guy[Y] = 0
        guy[VY] = 0
        guy[jumping]=False
    guy[VY] -= 1
        
def clearPlatforms2(guy):
    if platformMask2.get_at((guy[X],guy[Y])) != platforms:
        return True #if it doesnt hit platform
    else:
        return False #if it does

def clearPlatforms3(guy):
    if platformMask3.get_at((guy[X],guy[Y])) != platforms:
        return True #if it doesnt hit platform
    else:
        return False #if it does

def clearWalls(guy):
    if wallMask.get_at((guy[X],guy[Y])) != walls:
        return True #if it doesnt hit wall
    else:
        return False #if it does

def checkPlatforms(guy,platforms):
    if guy[page] == "lvl2":
        if guy[VY]>0 and clearPlatforms2((guy[X]+29,guy[Y]+36))==False: #if guy is hitting a platform
            guy[jumping]=False
            guy[VY] = 0
    if guy[page] == "lvl3":
        if guy[VY]>0 and clearPlatforms3((guy[X]+29,guy[Y]+36))==False: #if guy is hitting a platform
            guy[jumping]=False
            guy[VY] = 0 

def checkWalls(guy,walls):
    if clearWalls((guy[X]+29,guy[Y]+32))==False:
        print("die")
        #if guy dies, reset everything
        for i in range(len(drawing)):
            drawing[i] = True
        guy[angle] = 0
        guy[X] = 250
        guy[Y] = 478
        guy[score] = 0
        guy[progress] = 0
        guy[power] = False
        mixer.music.play(1)
        time.wait(300)

def checkSpikes(guy,spikes,spikes3):
    hitbox = Rect(guy[X],guy[Y],29,31)
    if guy[page] == "lvl2":
        for s in spikes:
            if hitbox.colliderect(s):
                for i in range(len(drawing)):
                    drawing[i] = True
                guy[angle] = 0
                guy[X] = 250
                guy[Y] = 478
                guy[score] = 0
                guy[progress] = 0
                guy[power] = False
                mixer.music.play(1)
                time.wait(300)
    if guy[page] == "lvl3":
        for s in spikes3:
            if hitbox.colliderect(s):
                for i in range(len(drawing2)):
                    drawing2[i] = True
                guy[angle] = 0
                guy[X] = 250
                guy[Y] = 478
                guy[shotX] = 250
                guy[score] = 0
                guy[power] = False
                mixer.music.play(1)
                time.wait(300)

def checkPowerup(guy):
    hitbox = Rect(guy[X],guy[Y],29,31)
    if hitbox.colliderect(powerup):
        guy[power] = True

def checkProgress(guy,progress):
    if guy[page] == "lvl2":
        if guy[progress] < 135:
            guy[progress] += 3/60

def levelEnd(guy):
    if guy[X] > 15400:
        guy[finalscore] = guy[score]
        screen.blit(lvlcom,(200,250))
        back = draw.rect(screen,darkblue,(325,325,150,50))
        if mb[0] == 1 and back.collidepoint(mx,my):
            guy[page] = "menu"
            guy[X] = 250
            guy[Y] = 478
            guy[score] = 0
            guy[progress] = 0
            guy[power] = False
            for i in range(len(drawing)):
                drawing[i] = True

def SpinJump(guy):
    if guy[page] == "lvl2":
        if guy[jumping] == True:
            guy[angle] -= 7 #if guy jumping make guy spin
            if guy[angle] < -360: 
                guy[angle] = 0 #so angle resets after 1 full rotation
        if guy[jumping] == False and guy[VY] > 1:
            guy[angle] -= 7 #if guy is falling make guy spin
        elif guy[jumping] == False:
            #makes angle based on what angle it lands
            #1st area
            if guy[angle] >= -315 and guy[angle] <=-224:
                guy[angle] = -270
            #2nd area
            if guy[angle] >= -225 and guy[angle] <=-134:
                guy[angle] = -180
            #3rd area
            if guy[angle] >= -135 and guy[angle] <=-44:
                guy[angle] = -90
            #4th area
            if guy[angle] <= -314 and guy[angle] >= -360:
                guy[angle] = 0
            if guy[angle] <= 0 and guy[angle] >= -45:
                guy[angle] = 0
    if guy[page] == "lvl3":
        if guy[jumping] == True:
            guy[angle] -= 7
            if guy[angle] < -360:
                guy[angle] = 0
        if guy[jumping] == False and guy[VY] > 1:
            guy[angle] -= 7
        elif guy[jumping] == False:
            if guy[angle] >= -315 and guy[angle] <=-224:
                guy[angle] = -270
            if guy[angle] >= -225 and guy[angle] <=-134:
                guy[angle] = -180
            if guy[angle] >= -135 and guy[angle] <=-44:
                guy[angle] = -90
            if guy[angle] <= -314 and guy[angle] >= -360:
                guy[angle] = 0
            if guy[angle] <= 0 and guy[angle] >= -45:
                guy[angle] = 0

running = True
clock = time.Clock()
guy = [250,478,0,False,0,0,"menu",0,"None",250,0,False]

platforms = (255,0,0,255) #platform mask
walls = (0,0,255,255) #wall mask

powerup = Rect(686,360,20,20)

#finds x and y from text files
jumpblocks = []
for i in range(0,len(jblockpos),2):
    jumpblocks.append(Rect(int(jblockpos[i]),int(jblockpos[i+1]),30,30))
breakblocks = []
for i in range(0,len(bblockpos),2):
    breakblocks.append(Rect(int(bblockpos[i]),258,20,250))
spikes = [Rect(2000,478,20,30)]
for i in range(0,len(spikepos),2):
    spikes.append(Rect(int(spikepos[i]),int(spikepos[i+1]),20,30))
spikes3 = [Rect(2000,478,20,30)]
for i in range(0,len(spikepos3),2):
    spikes3.append(Rect(int(spikepos3[i]),int(spikepos3[i+1]),20,30))
coins = [Rect(600,490,20,20)]
for i in range(0,len(coinpos),2):
    coins.append(Rect(int(coinpos[i]),int(coinpos[i+1]),10,10))

drawing = []
for i in range(len(coins)):
    drawing.append(True)
drawing2 = []
for i in range(len(breakblocks)):
    drawing2.append(True)

while running:
    for evnt in event.get():
        if evnt.type == QUIT:
            running = False

    mx,my = mouse.get_pos()
    mb = mouse.get_pressed()

    menu(guy,screen,page)
    #functions
    if guy[page] == "store":
        if guy[finalscore] >= 50:
            guy[finalscore] = guy[finalscore] - 50
            character1 = False
            character2 = True
            character3 = False
            guy[page] = "menu"
        else:
            guy[page] = "menu"
      
    if guy[page] == "lvl2":
        jump(guy)
        SpinJump(guy)
        move(guy)
        checkSpikes(guy,spikes,spikes3)
        checkPlatforms(guy,platforms)
        checkWalls(guy,walls)
        drawScene2(screen, guy,drawing)
        checkProgress(guy,progress)
        checkPowerup(guy)
        levelEnd(guy)
    if guy[page] == "lvl3":
        if guy[X] <= 8000 or guy[X] >= 13000:
            jump(guy)
            SpinJump(guy)
        else:
            upsidedownjump(guy)
            SpinJump(guy)
        move(guy)
        checkSpikes(guy,spikes,spikes3)
        checkPlatforms(guy,platforms)
        drawScene3(screen, guy,drawing)
        checkProgress(guy,progress)
        checkPowerup(guy)
        levelEnd(guy)


    clock.tick(60)
    display.flip()
quit()
