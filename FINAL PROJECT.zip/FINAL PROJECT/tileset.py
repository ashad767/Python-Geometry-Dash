from pygame import *
from random import *
from glob import *

def makeMap(pic,w,h):
    full = Surface((w,h))
    cols = set()
    pics = {}
    for x in range(pic.get_width()):
        for y in range(pic.get_height()):
            cols.add(tuple(pic.get_at((x,y))))
    print(cols)
    for c in cols:
        tile = glob("tiles/%d_%d_%d/*.png" % c[:3])[0]
        pics[c] = transform.scale(image.load(tile),(TILEX,TILEY))
    
    for x in range(pic.get_width()):
        for y in range(pic.get_height()):
            c = tuple(pic.get_at((x,y)))
            full.blit(pics[c], (x*TILEX, y*TILEY))
    return full

def drawScene(screen,back):
    screen.blit(back,(0,0))
    display.flip()

TILEX = 50
TILEY = 50

map1 = image.load("map.png")
#map1 = image.load("bv1m.png")
print(map1)
screen = display.set_mode((map1.get_width()*TILEX,map1.get_width()*TILEY))
back = makeMap(map1,screen.get_width(),screen.get_height())

running = True
myClock = time.Clock()
while running:
    for evnt in event.get():
        if evnt.type == QUIT:
            running = False

    drawScene(screen,back)
                    
    display.flip()
    myClock.tick(60)                        
    
quit()
