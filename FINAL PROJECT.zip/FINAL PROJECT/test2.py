from pygame import *
from random import randint

X=0
Y=1
VY=2
jumping=3
score=4
progress = 5
page = 6
angle = 7

darkblue = (30,144,255)

init()

screen = display.set_mode((800,600))
display.set_caption("Geometry Dash")
backPic = image.load("GeoBackground2.png")
platformMask = image.load("mask.png")
wallMask = image.load("mask2.png")
guyPicc = image.load("character.png")
guyPic = transform.scale(guyPicc,(29,31))
menuback = image.load("menubackground.png")
menubackground = transform.scale(menuback,(800,600))
title = image.load("geotitle.png")
geotitle = transform.scale(title,(300,50))

spikepos = open("spikes.txt").read().strip().replace(",","\n").split()
coinpos = open("coins.txt").read().strip().replace(",","\n").split()

finalscore = 0

def menu(guy,screen,page):
    screen.blit(menubackground,(0,0))
    screen.blit(geotitle,(225,50))
    buttons = [draw.rect(screen,darkblue,(300,150,150,50)),draw.rect(screen,darkblue,(300,250,150,50)),draw.rect(screen,darkblue,(300,350,150,50)),draw.rect(screen,darkblue,(300,450,150,50))]
    if buttons[0].collidepoint(mx,my):
        draw.rect(screen,(0,0,0),(300,150,150,50),1)
    if mb[0]==1 and buttons[0].collidepoint(mx,my):
        guy[page] = "sel"
    if guy[page] == "sel":
        screen.blit(menubackground,(0,0))
        screen.blit(geotitle,(225,50))
        levels = [draw.rect(screen,(255,0,0),(100,200,150,150)),draw.rect(screen,(255,0,0),(300,200,150,150)),draw.rect(screen,(255,0,0),(500,200,150,150))]
        if mb[0]==1 and levels[0].collidepoint(mx,my):
            guy[page]="lvl1"

def drawScene(screen,guy,drawing):

    offset = 250-guy[X]
    screen.blit(backPic, (offset,0))

    draw.line(screen,(0,0,0),(0,509),(10000,509),1)

    draw.rect(screen,(0,0,0),(325,20,135,15),1)
    draw.rect(screen,(0,255,0),(327,20,guy[progress],13))
    hitbox = Rect(guy[X],guy[Y],1,31)
    h = hitbox.move(offset,0)
    #draw.rect(screen,(0,0,0),h,1)

    for ss in spikes:
        s = ss.move(offset,0)
        draw.rect(screen,(255,0,0),s)

    for coin in range(len(coins)):
        c = coins[coin].move(offset,0)
        if drawing[coin] == True:
            draw.rect(screen,(255,255,0),c)
        if h.colliderect(c):
            guy[score] += 1
            drawing[coin] = False

    #if clearWalls((guy[X]+29,guy[Y]+32))==False:
       # for i in range(len(drawing)):
            #drawing[i] = True

        #if mask2.get_at((guy[X],guy[Y])) != walls:
            #drawing[coin] = True
        
    rotPic = transform.rotate(guyPic,guy[angle])
    screen.blit( rotPic, (250,guy[Y]))

def move(guy):
    if guy[X] < 9000:
        guy[X] += 10
    if guy[X] == 9000:
        finalscore == score

def jump(guy):
    keys = key.get_pressed()

    if keys[K_SPACE] and guy[jumping]==False:
        guy[VY] = -21
        guy[jumping]=True
              
    guy[Y]+=guy[VY]
    if guy[Y] >= 478:
        guy[Y] = 478
        guy[VY] = 0
        guy[jumping]=False
    guy[VY]+= 3

    if guy[jumping] == False:
        guy[angle] = 0


def clearPlatforms(guy):
    if platformMask.get_at((guy[X],guy[Y])) != platforms:
        return True
    else:
        return False

def clearWalls(guy):
    if wallMask.get_at((guy[X],guy[Y])) != walls:
        return True
    else:
        return False


def checkPlatforms(guy,platforms):
    if guy[VY]>0 and clearPlatforms((guy[X]+29,guy[Y]+36))==False:
        guy[jumping]=False
        guy[VY] = 0

def checkWalls(guy,walls):
    if clearWalls((guy[X]+29,guy[Y]+32))==False:
        print("die")
        for i in range(len(drawing)):
            drawing[i] = True
        guy[X] = 250
        guy[score] = 0
        guy[progress] = 0

def checkSpikes(guy,spikes):
    hitbox = Rect(guy[X],guy[Y],29,31)
    for s in spikes:
        if hitbox.colliderect(s):
            #print("die")
            for i in range(len(drawing)):
                drawing[i] = True
            guy[X] = 250
            guy[score] = 0
            guy[progress] = 0

def checkProgress(guy,progress):
    if guy[page] == "lvl1":
        if guy[progress] != 135:
            guy[progress] += 3/60

running = True
clock = time.Clock()
guy = [250,478,0,False,0,0,"menu",0]

platforms = (255,0,0,255)
walls = (0,0,255,255)

spikes = [Rect(2000,488,20,20)]
for i in range(0,len(spikepos),2):
    spikes.append(Rect(int(spikepos[i]),488,20,20))


coins = [Rect(600,490,10,10)]
for i in range(0,len(coins),2):
    coins.append(Rect(int(coinpos[i]),int(coinpos[i+1]),10,10))

drawing = []
for i in range(len(coins)):
    drawing.append(True)

while running:
    for evnt in event.get():
        if evnt.type == QUIT:
            running = False
    #print(spikes)
    mx,my = mouse.get_pos()
    mb = mouse.get_pressed()

    menu(guy,screen,page)
   # print(guy[page])

    print(guy[score])
    if guy[page] == "lvl1":
        jump(guy)
        move(guy)
        checkSpikes(guy,spikes)
        checkPlatforms(guy,platforms)
        checkWalls(guy,walls)
        drawScene(screen, guy,drawing)
        checkProgress(guy,progress)
    
    if guy[jumping] == True:
        guy[angle] -= 26


    clock.tick(60)

    display.flip()
quit()
